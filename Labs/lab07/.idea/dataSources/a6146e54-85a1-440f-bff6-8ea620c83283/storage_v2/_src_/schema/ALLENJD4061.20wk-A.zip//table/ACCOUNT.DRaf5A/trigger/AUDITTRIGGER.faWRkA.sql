create trigger AUDITTRIGGER
    after insert or update or delete
    on ACCOUNT
    for each row
DECLARE
    actiontype VARCHAR(7);
    newAuditID INTEGER;
    AuditUser CHAR(12);
BEGIN
    SELECT COUNT(*) INTO newAuditID FROM AuditLog;

    SELECT USER INTO AuditUser FROM DUAL;

    actiontype := CASE
        WHEN UPDATING THEN 'UPDATE'
        WHEN DELETING THEN 'DELETE'
        WHEN INSERTING THEN 'INSERT'
    END;

    INSERT INTO AuditLog VALUES (AuditIDSeq.nextval, SYSDATE, actiontype, 'Accounts', AuditUser);


END AuditTrigger;


/

